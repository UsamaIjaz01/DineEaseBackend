const hotelsData = [
    {
      name: 'Hotel A',
      slogan: 'A place to relax and enjoy',
      ratings: 4.5,
      startingPrice: 100,
    },
    {
      name: 'Hotel B',
      slogan: 'Luxury redefined',
      ratings: 4.8,
      startingPrice: 150,
    },
    {
      name: 'Hotel C',
      slogan: 'Your home away from home',
      ratings: 4.2,
      startingPrice: 80,
    },
  ];
  
  export default hotelsData;
  