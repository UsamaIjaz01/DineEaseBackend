import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema({
  userName: { type: String, required: true },
  orderedBy: { type: String, required: true },
  totalBill: { type: Number, required: true },
  items: [
    {
      name: { type: String, required: true },
      quantity: { type: Number, required: true }
    }
  ]
});

const Order = mongoose.model('orders', orderSchema);
export default Order;
