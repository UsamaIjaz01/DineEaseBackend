import express, { response } from "express";

const tableRequestsRouter = express.Router();
// Array to store table request data
let requestsData = [];
let removeID;
let responseData = [];
// Middleware to parse JSON requests
tableRequestsRouter.use(express.json());

// Route handler for handling table requests
tableRequestsRouter.post("/", async (req, res) => {

    ///// mobile se request idher atiii hainnnn 
    console.log("Table Request Router is hit");
    const { Id, Name, NoOfTables, NoOfChairs,  TimeInMinutes } = req.body;
    const approvalStatus = false;
    const request = { Id, Name, NoOfTables, NoOfChairs,  TimeInMinutes , approvalStatus};


    // ye m array m push krta jata hn request sab 
        requestsData.push(request); // Add request data to the array
        console.log("Sending response");
        res.status(200).send(Id);
});

// Route handler to get the current table request values

// ye get h yahan sy simply react sari request get krta h one by one
tableRequestsRouter.get("/", (req, res) => {
    res.json(requestsData);
});


const answerRouter = express.Router();
answerRouter.post("/", (req, res) => {

        console.log("Answer hit");
        var { approved, mobileID } = req.body;
        removeID = mobileID;
        // Determine the answer based on the value of 'approved'
        approved = approved ? 'Approved' : 'No Space';

        
        console.log(approved );
        console.log(mobileID);
        
        const response = {approved , mobileID};
        // Use the filter method to remove the object
        requestsData = requestsData.filter(element => element.Id !== mobileID);

        responseData.push(response);

});

answerRouter.get("/" , (req , res) => {
    console.log(responseData);
    res.send(responseData);
})



export { tableRequestsRouter, answerRouter };
