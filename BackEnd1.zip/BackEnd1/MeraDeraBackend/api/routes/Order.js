import express from 'express';
import bodyParser from 'body-parser';
import Order from '../../models/order.js';


const orderRouter = express.Router();
orderRouter.use(bodyParser.json());


orderRouter.post('/order', async (req, res) => {
  const { customerName, items, userName, price } = req.body;

  // Validate the request body
  if (!customerName || !Array.isArray(items) || items.length === 0 || !userName || !price) {
    return res.status(400).json({ error: 'Invalid order details' });
  }

  try {
    const orderData = {
      userName: userName,
      orderedBy: customerName,
      totalBill: price,
      items: items.map(item => ({
        name: item.name,
        quantity: item.quantity
      }))
    };

    console.log(orderData);
    const newOrder = await Order.create(orderData);
    res.status(201).json(newOrder);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Failed to process order' });
  }
});

// GET request to retrieve all orders for a specific userName
orderRouter.get('/orders/:userName', async (req, res) => {
  const { userName } = req.params;
  console.log(userName);

  try {
    const orders = await Order.find({ userName: userName });
    if (!orders) {
      return res.status(404).json({ error: 'No orders found for this user' });
    }
    res.status(200).json(orders);
  } catch (error) {
    console.error('Error retrieving orders:', error);
    res.status(500).json({ error: 'Failed to retrieve orders' });
  }
});


// orderRouter.post('/create-payment-intent', async (req, res) => {
//   console.log("IN NEW API");
//   const { payment_method, amount, currency } = req.body;

//   try {
//     const paymentIntent = await stripe.paymentIntents.create({
//       amount: amount,
//       currency: currency,
//       payment_method: payment_method,
//       confirmation_method: 'manual',
//       confirm: true,
//     });

//     res.json({ client_secret: paymentIntent.client_secret });
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// });


export default orderRouter;
