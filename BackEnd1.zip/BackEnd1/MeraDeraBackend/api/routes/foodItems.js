import express from "express";
import mongoose from "mongoose";


// Connect to MongoDB database
mongoose.connect('mongodb://127.0.0.1:27017/MeraDera', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB database');
});




const getFoodItemsRouter = express.Router();


// Define a schema for the "RegisteredRestaurants" collection
const foodItemSchema = new mongoose.Schema({
    name: String,
    price: Number,
    size: String,
    category: String,
    description: String,
    calories: Number,
    ingredients: [String],
    spiciness_level: Number
  });
  
  // Create a model for the "RegisteredRestaurants" collection
  const food = mongoose.model('meraderafooditems', foodItemSchema);
  
  
  // Route to fetch data from the "RegisteredRestaurants" collection
  getFoodItemsRouter.get('/', async (req, res) => {
    try {
      // Fetch data from the "MeraDeraFoodItems" collection
      const foodItems = await food.find();
  
      // Log the retrieved data for debugging
      // console.log("Retrieved food items:", foodItems);
  
      // Send the retrieved data as a response
      res.status(200).json(foodItems);
    } catch (error) {
      // Handle any errors that occur during the process
      console.error("Error fetching food items:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  
  
  export default getFoodItemsRouter;