import express from "express";
import bodyParser from "body-parser";
import getFoodItemsRouter from "./api/routes/foodItems.js";
import  { answerRouter, tableRequestsRouter }  from "./api/routes/getTableRequests.js";
import cors from "cors";
import orderRouter from "./api/routes/Order.js";
import mongoose from "mongoose";
import Stripe from 'stripe';

const stripe = new Stripe('sk_test_51PN7KfJhUYgoC6Lzcl36RnDVDhv6WXcN3pPVGlvHralwToh7m2ik4iZaOHBs4PwWYhMx6ZP99b9SGg61jzYBkwGi00moE1sKru');



const app = express();
const portNumber = 4000;


// Middleware to parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());

// Allow CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});



// Connect to MongoDB database
mongoose.connect('mongodb://127.0.0.1:27017/MeraDera', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB database');
});



app.get('/', (req, res) => {
    res.status(200).json({
        msg: "Hello app running"
    });
});


app.post('/payment', async (req, res) => {
    console.log("IN PAYMENT");
    console.log("IN PAYMENT");
    const { amount, currency } = req.body;
    const ammount = parseInt(amount, 10) * 100;
    console.log('this is amount -- >> $', ammount);
    console.log('this is currency -- >>', currency);
     // Convert amount to an integer
  
    try{
      const paymentIntent = await stripe.paymentIntents.create({
        amount: ammount , 
        currency: currency,

      });

        if(paymentIntent?.status !== 'completed'){
            console.log("In IF");
            return res.status(200).json({
              message: "Confirm payment please" , 
              client_secret: paymentIntent?.client_secret,
            })
        }

        return res.status(200).json({message: "Payment Completed"});
    } catch(err){
      console.log("THIS ERROR ::: " + err);
    }
});

app.use("/getFoodItems" , getFoodItemsRouter)
app.use("/tableRequests" , tableRequestsRouter)
app.use("/answer" , answerRouter)
app.use("/" , orderRouter)



app.listen(portNumber, () => {
    console.log(`Server is running on the port number # ${portNumber}`);
});
