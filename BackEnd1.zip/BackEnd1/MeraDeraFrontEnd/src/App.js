import React, { useEffect, useState } from 'react';
import './App.css';


function App() {
  const [requestList, setRequestList] = useState([]);

  useEffect(() => {
    const fetchData = () => {
      fetch('http://localhost:4000/tableRequests')
        .then(response => response.json())
        .then(data => {
          setRequestList(data);
          console.log(data);
        })
        .catch(error => console.error('Error fetching data:', error));
    };

    fetchData();

    const intervalId = setInterval(fetchData, 15000);

    return () => clearInterval(intervalId);
  }, []);

  const handleApproveClick = (Id) => {
    fetch(`http://localhost:4000/answer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ approved: true , mobileID : Id})
    })
    .then(response => {
      if (response.ok) {
        console.log('Request approved successfully');
      } else {
        console.error('Failed to approve request:', response.statusText);
      }
    })
    .catch(error => {
      console.error('Error approving request:', error);
    });
  };

  const handleRejectClick = (Id) => {
    fetch(`http://localhost:4000/answer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ approved: false , mobileID : Id})
    })
    .then(response => {
      if (response.ok) {
        console.log('Request rejected successfully');
      } else {
        console.error('Failed to reject request:', response.statusText);
      }
    })
    .catch(error => {
      console.error('Error rejecting request:', error);
    });
  };

  return (
    <div>
      <h2>Received Table Request Details</h2>
      {requestList.length === 0 ? (
        <p>NO REQUESTS AT THIS MOMENT</p>
      ) : (
        requestList.map(request => (
          <div key={request.Id} className="result-container">
            <p><strong>User Name:</strong> <span>{request.Name}</span></p>
            <p><strong>Number of Tables:</strong> <span>{request.NoOfTables}</span></p>
            <p><strong>Number of Chairs:</strong> <span>{request.NoOfChairs}</span></p>
            <p><strong>Time In Minutes:</strong> <span>{request.TimeInMinutes}</span></p>
            <button onClick={() => handleApproveClick(request.Id)}>Approved</button>
            <button onClick={() => handleRejectClick(request.Id)}>No Space</button>
          </div>
        ))
      )}
    </div>
  );
}

export default App;
